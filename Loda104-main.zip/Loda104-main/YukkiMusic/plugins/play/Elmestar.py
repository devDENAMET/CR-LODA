import asyncio
from typing import Union
from YukkiMusic import app
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton 
import pyrogram
from YukkiMusic.plugins.play.filters import command
from config import BANNED_USERS, MUSIC_BOT_NAME
from YukkiMusic.core.bot import YukkiBot
from YukkiMusic.misc import SUDOERS
from strings import get_command, get_string
from pyrogram import __version__ as pyrover
from pytgcalls import (__version__ as pytover)
from datetime import datetime
from sys import version_info
from time import time
from config import GITHUB_REPO, SUPPORT_CHANNEL, SUPPORT_GROUP




@app.on_message(command(["source", "سورس", "السورس"]) & filters.group & ~filters.edited)
async def elsouce(client: Client, message: Message):
    await message.reply_photo(
        photo=f"https://telegra.ph/file/3fa58067f08f47cc78efb.jpg",
        caption=f"""<b>◉ اهلا بك في سورس لودا .\n{MUSIC_BOT_NAME} اسمي.\n\n انا بوت تشغيل الاغاني في المحادثات الصوتيه.\n° اذا واجهتك مشكله تواصل مع المستر من خلال زر [مبرمج السورس ] </b>""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "قناة السورس", url=f"{SUPPORT_CHANNEL}")
                ]
            ]
        ),
    ) 




@app.on_message(
    command(["جول"])
    & filters.group
    & ~filters.edited
)
def echo(client, msg):
    text = msg.text.split(None, 1)[1]
    msg.reply(text)

@app.on_message(
    command(["انا مين"])
    & filters.group
    & ~filters.edited
)
async def khalid(client: Client, message: Message):
    if message.from_user.id in SUDOERS:
        await message.reply_text("المبرمج روحقلبي😍")
    else:
        await message.reply_text("انسان عادي")
    usr = await client.get_users(5274610090)
    name = usr.first_name



@app.on_message(command(["رتبتي"]) & filters.user(5241548008))
async def rutbete(client: Client, message: Message):

    usr = await client.get_users(5241548008)

    name = usr.first_name

    async for photo in client.iter_profile_photos(5241548008, limit=1):

                    await message.reply_photo(photo.file_id,        caption=f"[مبرمج السورس ي قلبي 🌝💕](https://t.me/UU_O_M_A_R)",  

        reply_markup=InlineKeyboardMarkup(

            [

                [

                    InlineKeyboardButton(

                        name, url=f"https://t.me/UU_O_M_A_R") 
                ],[

                    InlineKeyboardButton(

                        "SOURCE", url=f"https://t.me/mr_kh_alid")

                ],

            ]

        ),

    )


@app.on_message(command(["رتبتي"]) & filters.user(831816852))
async def rutbete(client: Client, message: Message):

    usr = await client.get_users(831816852)

    name = usr.first_name

    async for photo in client.iter_profile_photos(831816852, limit=1):

                    await message.reply_photo(photo.file_id,        caption=f"[مبرمج السورس ي قلبي 🌝💕](https://t.me/khalidvip)",  

        reply_markup=InlineKeyboardMarkup(

            [

                [

                    InlineKeyboardButton(

                        name, url=f"https://t.me/khalidvip") 
                ],[

                    InlineKeyboardButton(

                        "SOURCE", url=f"https://t.me/mr_kh_alid")

                ],

            ]

        ),

    )


@app.on_message(command(["رتبتي"]) & filters.user(1914052494))
async def rutbete(client: Client, message: Message):

    usr = await client.get_users(1914052494)

    name = usr.first_name

    async for photo in client.iter_profile_photos(1914052494, limit=1):

                    await message.reply_photo(photo.file_id,        caption=f"[مبرمج السورس ي قلبي 🌝💕](https://t.me/xxy_bu)",  

        reply_markup=InlineKeyboardMarkup(

            [

                [

                    InlineKeyboardButton(

                        name, url=f"https://t.me/xxy_bu") 
                ],[

                    InlineKeyboardButton(

                        "SOURCE", url=f"https://t.me/crcmodel2")

                ],

            ]

        ),

    )


@app.on_message(command(["khalid", "خالد"]) & filters.group & ~filters.edited)
async def rutbete(client: Client, message: Message):

    usr = await client.get_users(1914052494)

    name = usr.first_name

    async for photo in client.iter_profile_photos(1914052494, limit=1):

                    await message.reply_photo(photo.file_id,        caption=f"[مبرمج السورس ي قلبي 🌝💕](https://t.me/xxy_bu)",  

        reply_markup=InlineKeyboardMarkup(

            [

                [

                    InlineKeyboardButton(

                        name, url=f"https://t.me/xxy_bu") 
                ],[

                    InlineKeyboardButton(

                        "SOURCE", url=f"https://t.me/crcmodel2")

                ],

            ]

        ),

    )


